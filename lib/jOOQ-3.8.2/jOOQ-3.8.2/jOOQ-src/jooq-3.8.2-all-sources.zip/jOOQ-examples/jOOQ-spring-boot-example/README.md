Thanks for downloading jOOQ.
Please visit http://www.jooq.org for more information.

This example was inspired by Petri Kainulainen's excellent blog post:
http://www.petrikainulainen.net/programming/jooq/using-jooq-with-spring-configuration/

... and then modified by @thomasdarimont to show how Spring Boot could be used

To install and run this example, please check out the complete jOOQ repository first, and use Maven to install the latest SNAPSHOT version of jOOQ:

```
$ pwd
/path/to/checkout/dir
$ ls
jOOQ jOOQ-meta jOOQ-codegen ...
$ mvn clean install
...
$ cd jOOQ-examples/jOOQ-spring-boot-example
...
$ mvn clean install
```
