The jOOQ Academy is an extended, fully functional and runnable tutorial that is being created in cooperation with the
[Java Code Geeks Academy](http://academy.javacodegeeks.com/). The course material can be found here:

http://academy.javacodegeeks.com/course/type-safe-database-querying-with-jooq

Use the following commands to build the jOOQ Academy:

```
$ pwd
/path/to/checkout/dir
$ ls
jOOQ jOOQ-meta jOOQ-codegen ...
$ mvn clean install
...
$ cd jOOQ-examples/jOOQ-academy
...
$ mvn clean install
```
